// 관리자 페이지 로직

// 현재 상태
let currentTab = 'reports';
let currentReportStatus = 'p'; // pending

// Note: getChannelInfo 함수는 utils.js에서 제공됩니다.

// 초기화
document.addEventListener('DOMContentLoaded', async () => {
  console.log('🔧 관리자 페이지 초기화');

  try {
    // 인증 확인
    await ensureAuthenticated();
    const user = auth.currentUser;

    // 관리자 권한 체크
    if (!isAdmin(user.uid)) {
      showNoAccess(user.uid);
      return;
    }

    // 관리자 패널 표시
    showAdminPanel(user.uid);

    // 대시보드 로드
    await loadDashboard();

    // 초기 탭 로드
    await loadTabContent('reports');

    // 이벤트 리스너 설정
    setupEventListeners();

  } catch (error) {
    console.error('초기화 오류:', error);
    alert('초기화 중 오류가 발생했습니다: ' + error.message);
  }
});

// 권한 없음 표시
function showNoAccess(uid) {
  document.getElementById('authCheck').style.display = 'none';
  document.getElementById('noAccess').style.display = 'flex';
  document.getElementById('currentUserId').textContent = uid;
}

// 관리자 패널 표시
function showAdminPanel(uid) {
  document.getElementById('authCheck').style.display = 'none';
  document.getElementById('adminPanel').style.display = 'block';
  document.getElementById('adminUserId').textContent = uid.slice(0, 12) + '...';
}

// 대시보드 로드
async function loadDashboard() {
  try {
    const stats = await getAdminStats();

    document.getElementById('totalTimetables').textContent = stats.total;
    document.getElementById('pendingReports').textContent = stats.pendingReports;
    document.getElementById('removedTimetables').textContent = stats.removed;
    document.getElementById('hiddenTimetables').textContent = stats.hidden;

    console.log('✅ 대시보드 로드 완료:', stats);
  } catch (error) {
    console.error('대시보드 로드 오류:', error);
  }
}

// 탭 컨텐츠 로드
async function loadTabContent(tab) {
  currentTab = tab;

  // 탭 버튼 활성화
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tab);
  });

  // 탭 패널 활성화
  document.querySelectorAll('.tab-pane').forEach(pane => {
    pane.classList.toggle('active', pane.id === `tab-${tab}`);
  });

  // 데이터 로드
  switch (tab) {
    case 'reports':
      await loadReports(currentReportStatus);
      break;
    case 'removed':
      await loadRemovedTimetables();
      break;
    case 'hidden':
      await loadHiddenTimetables();
      break;
    case 'all':
      await loadAllTimetables();
      break;
  }
}

// 신고 목록 로드
async function loadReports(status) {
  const container = document.getElementById('reportsList');
  container.innerHTML = '<div class="loading">신고 목록을 불러오는 중...</div>';

  try {
    const reports = await getReports(status);

    if (reports.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📋</div>
          <p>신고가 없습니다.</p>
        </div>
      `;
      return;
    }

    // 각 신고에 대해 시간표 정보 가져오기
    const reportsWithTimetables = await Promise.all(
      reports.map(async (report) => {
        const timetable = await getTimetableById(report.timetableId);
        return { ...report, timetable };
      })
    );

    container.innerHTML = reportsWithTimetables.map(report => {
      const tt = report.timetable;
      const hasImage = tt && tt.imageUrl;

      return `
        <div class="data-item" data-id="${report.id}" ${tt ? `data-channel-id="${tt.channelId}"` : ''}>
          <div class="item-header">
            <div class="item-info">
              <div class="item-title ${tt ? 'channel-title' : ''}">
                ${tt ? `채널: <span class="channel-name">불러오는 중...</span>` : `시간표 ID: ${report.timetableId}`}
              </div>
              <div class="item-meta">
                ${tt ? `<span>📅 ${tt.weekStart} ~ ${tt.weekEnd}</span>` : ''}
                <span>🚨 신고: ${getRelativeTime(report.reportedAt)}</span>
                <span>👤 신고자: ${report.reportedBy.slice(0, 8)}...</span>
                <span class="status-badge status-${status === 'p' ? 'pending' : status === 'a' ? 'approved' : 'rejected'}">
                  ${status === 'p' ? '대기 중' : status === 'a' ? '승인됨' : '거부됨'}
                </span>
              </div>
            </div>
            <div class="item-actions">
              ${status === 'p' ? `
                <button class="btn btn-approve" data-action="approve-report" data-report-id="${report.id}" data-timetable-id="${report.timetableId}">
                  ✅ 승인 (삭제)
                </button>
                <button class="btn btn-reject" data-action="reject-report" data-report-id="${report.id}">
                  ❌ 거부
                </button>
              ` : ''}
            </div>
          </div>
          <div class="item-content">
            ${hasImage ? `<img src="${tt.imageUrl}" alt="시간표" class="item-image" data-image-url="${tt.imageUrl}" />` : '<p style="color: #999;">시간표가 삭제되었거나 찾을 수 없습니다.</p>'}
            <div class="item-reason">
              <strong>신고 사유:</strong> ${report.reason}
            </div>
          </div>
        </div>
      `;
    }).join('');

    // 이미지 클릭 이벤트 추가
    container.querySelectorAll('.item-image').forEach(img => {
      img.addEventListener('click', () => {
        showImageModal(img.getAttribute('data-image-url'));
      });
      img.style.cursor = 'pointer';
    });

    // 채널 정보 가져오기
    const channelIds = new Set();
    reportsWithTimetables.forEach(report => {
      if (report.timetable) {
        channelIds.add(report.timetable.channelId);
      }
    });

    for (const channelId of channelIds) {
      const channelInfo = await getChannelInfo(channelId);
      container.querySelectorAll(`[data-channel-id="${channelId}"] .channel-name`).forEach(el => {
        el.textContent = channelInfo.name;
      });
    }

    // 버튼 이벤트 리스너 추가
    setupActionListeners(container);

  } catch (error) {
    console.error('신고 로드 오류:', error);
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">❌</div>
        <p>오류가 발생했습니다.</p>
      </div>
    `;
  }
}

// 삭제된 시간표 로드
async function loadRemovedTimetables() {
  const container = document.getElementById('removedList');
  container.innerHTML = '<div class="loading">삭제된 시간표를 불러오는 중...</div>';

  try {
    const timetables = await getRemovedTimetables();

    if (timetables.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📋</div>
          <p>삭제된 시간표가 없습니다.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = timetables.map(tt => `
      <div class="data-item" data-id="${tt.id}" data-channel-id="${tt.channelId}">
        <div class="item-header">
          <div class="item-info">
            <div class="item-title channel-title">
              채널: <span class="channel-name">불러오는 중...</span>
            </div>
            <div class="item-meta">
              <span>📅 ${tt.weekStart} ~ ${tt.weekEnd}</span>
              <span>👤 업로더: ${tt.uploadedByHash}</span>
              <span>👍 ${tt.likes}</span>
              <span>👎 ${tt.dislikes}</span>
            </div>
          </div>
          <div class="item-actions">
            <button class="btn btn-restore" data-action="restore-timetable" data-timetable-id="${tt.id}">
              ♻️ 복구 (내 ID로)
            </button>
            <button class="btn btn-delete" data-action="permanently-delete" data-timetable-id="${tt.id}">
              🗑️ 영구 삭제
            </button>
          </div>
        </div>
        <div class="item-content">
          <img src="${tt.imageUrl}" alt="시간표" class="item-image" data-image-url="${tt.imageUrl}" />
          <div class="item-url">
            <div class="url-display">
              <strong>이미지 URL:</strong>
              <span class="url-text">${tt.imageUrl}</span>
              <button class="btn-edit-url" data-action="edit-url" data-timetable-id="${tt.id}">✏️ 수정</button>
            </div>
            <div class="url-edit" style="display: none;">
              <input type="text" class="url-input" value="${tt.imageUrl}" />
              <button class="btn btn-approve" data-action="save-url" data-timetable-id="${tt.id}">💾 저장</button>
              <button class="btn btn-reject" data-action="cancel-edit-url" data-timetable-id="${tt.id}">❌ 취소</button>
            </div>
          </div>
        </div>
      </div>
    `).join('');

    // 이미지 클릭 이벤트 추가
    container.querySelectorAll('.item-image').forEach(img => {
      img.addEventListener('click', function() {
        const imageUrl = this.getAttribute('data-image-url');
        showImageModal(imageUrl);
      });
    });

    // 채널 정보 비동기 로드
    container.querySelectorAll('.data-item').forEach(async (item) => {
      const channelId = item.getAttribute('data-channel-id');
      const channelNameSpan = item.querySelector('.channel-name');

      if (channelId && channelNameSpan) {
        const channelInfo = await getChannelInfo(channelId);
        channelNameSpan.textContent = `${channelInfo.name} (${channelId})`;
      }
    });

    // URL 편집 버튼 이벤트 리스너 추가
    setupUrlEditListeners(container);

  } catch (error) {
    console.error('삭제된 시간표 로드 오류:', error);
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">❌</div>
        <p>오류가 발생했습니다.</p>
      </div>
    `;
  }
}

// 숨겨진 시간표 로드
async function loadHiddenTimetables() {
  const container = document.getElementById('hiddenList');
  container.innerHTML = '<div class="loading">숨겨진 시간표를 불러오는 중...</div>';

  try {
    const timetables = await getHiddenTimetables();

    if (timetables.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📋</div>
          <p>숨겨진 시간표가 없습니다.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = timetables.map(tt => `
      <div class="data-item" data-id="${tt.id}" data-channel-id="${tt.channelId}">
        <div class="item-header">
          <div class="item-info">
            <div class="item-title channel-title">
              채널: <span class="channel-name">불러오는 중...</span>
            </div>
            <div class="item-meta">
              <span>📅 ${tt.weekStart} ~ ${tt.weekEnd}</span>
              <span>👤 업로더: ${tt.uploadedByHash}</span>
              <span>👍 ${tt.likes}</span>
              <span>👎 ${tt.dislikes}</span>
              <span style="color: #f44336;">점수: ${tt.score}</span>
            </div>
          </div>
          <div class="item-actions">
            <button class="btn btn-restore" data-action="unhide-timetable" data-timetable-id="${tt.id}">
              👁️ 숨김 해제
            </button>
            <button class="btn btn-delete" data-action="delete-timetable" data-timetable-id="${tt.id}">
              🗑️ 삭제
            </button>
          </div>
        </div>
        <div class="item-content">
          <img src="${tt.imageUrl}" alt="시간표" class="item-image" data-image-url="${tt.imageUrl}" />
          <div class="item-url">
            <div class="url-display">
              <strong>이미지 URL:</strong>
              <span class="url-text">${tt.imageUrl}</span>
              <button class="btn-edit-url" data-action="edit-url" data-timetable-id="${tt.id}">✏️ 수정</button>
            </div>
            <div class="url-edit" style="display: none;">
              <input type="text" class="url-input" value="${tt.imageUrl}" />
              <button class="btn btn-approve" data-action="save-url" data-timetable-id="${tt.id}">💾 저장</button>
              <button class="btn btn-reject" data-action="cancel-edit-url" data-timetable-id="${tt.id}">❌ 취소</button>
            </div>
          </div>
        </div>
      </div>
    `).join('');

    // 이미지 클릭 이벤트 추가
    container.querySelectorAll('.item-image').forEach(img => {
      img.addEventListener('click', function() {
        const imageUrl = this.getAttribute('data-image-url');
        showImageModal(imageUrl);
      });
    });

    // 채널 정보 비동기 로드
    container.querySelectorAll('.data-item').forEach(async (item) => {
      const channelId = item.getAttribute('data-channel-id');
      const channelNameSpan = item.querySelector('.channel-name');

      if (channelId && channelNameSpan) {
        const channelInfo = await getChannelInfo(channelId);
        channelNameSpan.textContent = `${channelInfo.name} (${channelId})`;
      }
    });

    // URL 편집 버튼 이벤트 리스너 추가
    setupUrlEditListeners(container);

  } catch (error) {
    console.error('숨겨진 시간표 로드 오류:', error);
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">❌</div>
        <p>오류가 발생했습니다.</p>
      </div>
    `;
  }
}

// 전체 시간표 로드
async function loadAllTimetables(channelId = null) {
  const container = document.getElementById('allTimetablesList');
  container.innerHTML = '<div class="loading">전체 시간표를 불러오는 중...</div>';

  try {
    const timetables = await getAllTimetables(channelId, 100);

    if (timetables.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📋</div>
          <p>시간표가 없습니다.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = timetables.map(tt => `
      <div class="data-item" data-id="${tt.id}" data-channel-id="${tt.channelId}">
        <div class="item-header">
          <div class="item-info">
            <div class="item-title channel-title">
              채널: <span class="channel-name">불러오는 중...</span>
            </div>
            <div class="item-meta">
              <span>📅 ${tt.weekStart} ~ ${tt.weekEnd}</span>
              <span>👤 업로더: ${tt.uploadedByHash}</span>
              <span>👍 ${tt.likes}</span>
              <span>👎 ${tt.dislikes}</span>
              <span>점수: ${tt.score}</span>
              <span>⏰ ${getRelativeTime(tt.uploadedAt)}</span>
            </div>
          </div>
          <div class="item-actions">
            <button class="btn btn-delete" data-action="delete-timetable" data-timetable-id="${tt.id}">
              🗑️ 삭제
            </button>
            <button class="btn btn-view" data-action="hide-timetable" data-timetable-id="${tt.id}">
              👁️ 숨기기
            </button>
          </div>
        </div>
        <div class="item-content">
          <img src="${tt.imageUrl}" alt="시간표" class="item-image" data-image-url="${tt.imageUrl}" />
          <div class="item-url">
            <div class="url-display">
              <strong>이미지 URL:</strong>
              <span class="url-text">${tt.imageUrl}</span>
              <button class="btn-edit-url" data-action="edit-url" data-timetable-id="${tt.id}">✏️ 수정</button>
            </div>
            <div class="url-edit" style="display: none;">
              <input type="text" class="url-input" value="${tt.imageUrl}" />
              <button class="btn btn-approve" data-action="save-url" data-timetable-id="${tt.id}">💾 저장</button>
              <button class="btn btn-reject" data-action="cancel-edit-url" data-timetable-id="${tt.id}">❌ 취소</button>
            </div>
          </div>
        </div>
      </div>
    `).join('');

    // 이미지 클릭 이벤트 추가
    container.querySelectorAll('.item-image').forEach(img => {
      img.addEventListener('click', function() {
        const imageUrl = this.getAttribute('data-image-url');
        showImageModal(imageUrl);
      });
    });

    // 채널 정보 비동기 로드
    container.querySelectorAll('.data-item').forEach(async (item) => {
      const channelId = item.getAttribute('data-channel-id');
      const channelNameSpan = item.querySelector('.channel-name');

      if (channelId && channelNameSpan) {
        const channelInfo = await getChannelInfo(channelId);
        channelNameSpan.textContent = `${channelInfo.name} (${channelId})`;
      }
    });

    // URL 편집 버튼 이벤트 리스너 추가
    setupUrlEditListeners(container);

  } catch (error) {
    console.error('전체 시간표 로드 오류:', error);
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">❌</div>
        <p>오류가 발생했습니다.</p>
      </div>
    `;
  }
}

// 이벤트 리스너 설정
function setupEventListeners() {
  // 탭 버튼
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      loadTabContent(btn.dataset.tab);
    });
  });

  // 신고 상태 필터
  document.querySelectorAll('input[name="reportStatus"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      currentReportStatus = e.target.value;
      loadReports(currentReportStatus);
    });
  });

  // 새로고침 버튼
  document.getElementById('refreshStats').addEventListener('click', async () => {
    await loadDashboard();
    await loadTabContent(currentTab);
  });

  // 전체 시간표 검색
  document.getElementById('searchBtn').addEventListener('click', async () => {
    const channelId = document.getElementById('channelFilter').value.trim();
    await loadAllTimetables(channelId || null);
  });

  // 필터 초기화
  document.getElementById('clearFilterBtn').addEventListener('click', async () => {
    document.getElementById('channelFilter').value = '';
    await loadAllTimetables();
  });

  // Enter 키로 검색
  document.getElementById('channelFilter').addEventListener('keypress', async (e) => {
    if (e.key === 'Enter') {
      const channelId = e.target.value.trim();
      await loadAllTimetables(channelId || null);
    }
  });
}

// 신고 승인 (시간표 삭제)
async function approveReport(reportId, timetableId) {
  if (!confirm('이 신고를 승인하고 시간표를 삭제하시겠습니까?')) return;

  try {
    await approveReportAdmin(reportId, timetableId);
    alert('✅ 신고가 승인되고 시간표가 삭제되었습니다.');
    await loadReports(currentReportStatus);
    await loadDashboard();
  } catch (error) {
    console.error('신고 승인 오류:', error);
    alert('오류: ' + error.message);
  }
}

// 신고 거부
async function rejectReport(reportId) {
  if (!confirm('이 신고를 거부하시겠습니까?')) return;

  try {
    await rejectReportAdmin(reportId);
    alert('✅ 신고가 거부되었습니다.');
    await loadReports(currentReportStatus);
    await loadDashboard();
  } catch (error) {
    console.error('신고 거부 오류:', error);
    alert('오류: ' + error.message);
  }
}

// 시간표 복구 (관리자 ID로)
async function restoreTimetable(timetableId) {
  if (!confirm('이 시간표를 복구하시겠습니까?\n\n복구 시 업로더 ID가 관리자 ID로 변경됩니다.')) return;

  try {
    await restoreTimetableAdmin(timetableId);
    alert('✅ 시간표가 복구되었습니다.');
    await loadRemovedTimetables();
    await loadDashboard();
  } catch (error) {
    console.error('시간표 복구 오류:', error);
    alert('오류: ' + error.message);
  }
}

// 시간표 영구 삭제
async function permanentlyDeleteTimetable(timetableId) {
  if (!confirm('⚠️ 경고: 이 시간표를 영구적으로 삭제하시겠습니까?\n\n이 작업은 되돌릴 수 없습니다!')) return;

  try {
    await permanentlyDeleteTimetableAdmin(timetableId);
    alert('✅ 시간표가 영구 삭제되었습니다.');
    await loadRemovedTimetables();
    await loadDashboard();
  } catch (error) {
    console.error('영구 삭제 오류:', error);
    alert('오류: ' + error.message);
  }
}

// 시간표 숨김 해제
async function unhideTimetable(timetableId) {
  if (!confirm('이 시간표의 숨김을 해제하시겠습니까?')) return;

  try {
    await unhideTimetableAdmin(timetableId);
    alert('✅ 시간표 숨김이 해제되었습니다.');
    await loadHiddenTimetables();
    await loadDashboard();
  } catch (error) {
    console.error('숨김 해제 오류:', error);
    alert('오류: ' + error.message);
  }
}

// 숨겨진 시간표 삭제
async function deleteTimetableAsAdmin(timetableId) {
  if (!confirm('이 시간표를 삭제하시겠습니까?')) return;

  try {
    await deleteTimetableAdmin(timetableId);
    alert('✅ 시간표가 삭제되었습니다.');
    await loadHiddenTimetables();
    await loadDashboard();
  } catch (error) {
    console.error('시간표 삭제 오류:', error);
    alert('오류: ' + error.message);
  }
}

// 시간표 보기
async function viewTimetable(timetableId) {
  try {
    const timetable = await getTimetableById(timetableId);
    if (timetable && timetable.imageUrl) {
      window.open(timetable.imageUrl, '_blank');
    } else {
      alert('시간표를 찾을 수 없습니다.');
    }
  } catch (error) {
    console.error('시간표 보기 오류:', error);
    alert('오류: ' + error.message);
  }
}

// 시간표 숨기기 (관리자)
async function hideTimetableAsAdmin(timetableId) {
  if (!confirm('이 시간표를 숨기시겠습니까?')) return;

  try {
    await db.collection('timetables').doc(timetableId).update({ h: true });
    alert('✅ 시간표가 숨겨졌습니다.');
    await loadAllTimetables();
    await loadDashboard();
  } catch (error) {
    console.error('시간표 숨기기 오류:', error);
    alert('오류: ' + error.message);
  }
}

// URL 편집 버튼 이벤트 리스너 설정
function setupActionListeners(container) {
  // 모든 버튼에 이벤트 위임 사용
  container.addEventListener('click', (e) => {
    const button = e.target.closest('[data-action]');
    if (!button) return;

    const action = button.getAttribute('data-action');
    const timetableId = button.getAttribute('data-timetable-id');
    const reportId = button.getAttribute('data-report-id');

    switch (action) {
      // 신고 관련
      case 'approve-report':
        if (reportId && timetableId) {
          approveReport(reportId, timetableId);
        }
        break;
      case 'reject-report':
        if (reportId) {
          rejectReport(reportId);
        }
        break;
      case 'view-timetable':
        if (timetableId) {
          viewTimetable(timetableId);
        }
        break;

      // 시간표 관리
      case 'restore-timetable':
        if (timetableId) {
          restoreTimetable(timetableId);
        }
        break;
      case 'permanently-delete':
        if (timetableId) {
          permanentlyDeleteTimetable(timetableId);
        }
        break;
      case 'unhide-timetable':
        if (timetableId) {
          unhideTimetable(timetableId);
        }
        break;
      case 'delete-timetable':
        if (timetableId) {
          deleteTimetableAsAdmin(timetableId);
        }
        break;
      case 'hide-timetable':
        if (timetableId) {
          hideTimetableAsAdmin(timetableId);
        }
        break;

      // URL 편집
      case 'edit-url':
        if (timetableId) {
          editImageUrl(timetableId);
        }
        break;
      case 'save-url':
        if (timetableId) {
          saveImageUrl(timetableId);
        }
        break;
      case 'cancel-edit-url':
        if (timetableId) {
          cancelEditUrl(timetableId);
        }
        break;
    }
  });
}

// 하위 호환성을 위한 별칭
function setupUrlEditListeners(container) {
  setupActionListeners(container);
}

// 이미지 모달 표시
function showImageModal(imageUrl) {
  // 기존 모달 제거
  const existingModal = document.querySelector('.image-modal');
  if (existingModal) {
    existingModal.remove();
  }

  // 모달 생성
  const modal = document.createElement('div');
  modal.className = 'image-modal';
  modal.innerHTML = `
    <div class="image-modal-overlay"></div>
    <div class="image-modal-content">
      <button class="image-modal-close">&times;</button>
      <img src="${imageUrl}" alt="시간표 확대" class="image-modal-image">
    </div>
  `;

  document.body.appendChild(modal);

  // 닫기 이벤트
  const closeModal = () => modal.remove();

  modal.querySelector('.image-modal-overlay').addEventListener('click', closeModal);
  modal.querySelector('.image-modal-close').addEventListener('click', closeModal);

  // ESC 키로 닫기
  const handleEscape = (e) => {
    if (e.key === 'Escape') {
      closeModal();
      document.removeEventListener('keydown', handleEscape);
    }
  };
  document.addEventListener('keydown', handleEscape);
}

// 이미지 URL 수정 모드 전환
function editImageUrl(timetableId) {
  const item = document.querySelector(`.data-item[data-id="${timetableId}"]`);
  if (!item) return;

  const urlDisplay = item.querySelector('.url-display');
  const urlEdit = item.querySelector('.url-edit');

  if (urlDisplay && urlEdit) {
    urlDisplay.style.display = 'none';
    urlEdit.style.display = 'flex';

    // 입력 필드에 포커스
    const input = urlEdit.querySelector('.url-input');
    if (input) {
      input.focus();
      input.select();
    }
  }
}

// 이미지 URL 수정 취소
function cancelEditUrl(timetableId) {
  const item = document.querySelector(`.data-item[data-id="${timetableId}"]`);
  if (!item) return;

  const urlDisplay = item.querySelector('.url-display');
  const urlEdit = item.querySelector('.url-edit');
  const urlInput = item.querySelector('.url-input');
  const originalUrl = item.querySelector('.url-text').textContent;

  if (urlDisplay && urlEdit && urlInput) {
    // 원래 URL로 복원
    urlInput.value = originalUrl;

    // UI 전환
    urlEdit.style.display = 'none';
    urlDisplay.style.display = 'flex';
  }
}

// 이미지 URL 저장
async function saveImageUrl(timetableId) {
  const item = document.querySelector(`.data-item[data-id="${timetableId}"]`);
  if (!item) return;

  const urlInput = item.querySelector('.url-input');
  const newUrl = urlInput.value.trim();

  if (!newUrl) {
    alert('URL을 입력해주세요.');
    return;
  }

  // URL 형식 검증
  if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
    alert('유효한 이미지 URL을 입력해주세요.\n(http:// 또는 https://로 시작해야 합니다)');
    return;
  }

  // 저장 버튼 비활성화
  const saveBtn = item.querySelector('.url-edit .btn-approve');
  const cancelBtn = item.querySelector('.url-edit .btn-reject');
  if (saveBtn) saveBtn.disabled = true;
  if (cancelBtn) cancelBtn.disabled = true;

  try {
    // Firebase 업데이트
    await updateTimetableImageUrl(timetableId, newUrl);

    // UI 업데이트
    const urlText = item.querySelector('.url-text');
    const itemImage = item.querySelector('.item-image');

    if (urlText) urlText.textContent = newUrl;
    if (itemImage) {
      itemImage.src = newUrl;
      itemImage.setAttribute('data-image-url', newUrl);
    }

    // 편집 모드 종료
    const urlDisplay = item.querySelector('.url-display');
    const urlEdit = item.querySelector('.url-edit');

    if (urlDisplay && urlEdit) {
      urlEdit.style.display = 'none';
      urlDisplay.style.display = 'flex';
    }

    alert('✅ 이미지 URL이 성공적으로 수정되었습니다.');

  } catch (error) {
    console.error('이미지 URL 수정 오류:', error);
    alert('오류: ' + error.message);
  } finally {
    // 버튼 다시 활성화
    if (saveBtn) saveBtn.disabled = false;
    if (cancelBtn) cancelBtn.disabled = false;
  }
}

console.log('✅ Admin script loaded');
